module com.example.paintsprint {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.swing;
    opens com.example.paintsprint to javafx.fxml;
    exports com.example.paintsprint;
}